class User {
  final int id;
  final String email;

  const User(this.id, this.email);
}
