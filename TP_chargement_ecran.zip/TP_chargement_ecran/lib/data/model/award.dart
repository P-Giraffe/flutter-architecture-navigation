class Award {
  final String title;
  final int year;

  const Award(this.title, this.year);
}
