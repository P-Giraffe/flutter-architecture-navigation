class NavigationPath {
  final int? userId;

  const NavigationPath({required this.userId});
}
