import 'package:flutter_avance/data/model/award.dart';
import 'package:flutter_avance/data/model/user.dart';
import 'package:flutter_avance/ui/screens/user_home_screen.dart';

import '../../data/controllers/remote_data_manager.dart';
import '../../data/use_cases/user_awards_use_cases.dart';

abstract class UserHomeRouter {
  displaySettings();
  void logoutCurrentUser();
}

class UserHomeViewModel extends IUserHomeViewModel {
  final User _user;
  final UserHomeRouter _router;
  final RemoteDataManager _remoteDataManager;

  UserHomeViewModel(this._user, this._router, this._remoteDataManager);
  @override
  String get email => _user.email;

  @override
  List<Award> userAwards = [];

  Future<List<Award>> loadAwardList() async {
    final useCase = UserAwardsUseCases(_remoteDataManager);
    userAwards = await useCase.fetchAll();
    return userAwards;
  }

  @override
  void userTouchedSettingsButton() {
    _router.displaySettings();
  }

  @override
  void userTouchedLogoutButton() {
    _router.logoutCurrentUser();
  }
}
