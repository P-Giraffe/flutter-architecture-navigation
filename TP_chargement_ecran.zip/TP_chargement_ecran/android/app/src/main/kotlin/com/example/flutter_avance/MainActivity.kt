package com.example.flutter_avance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
